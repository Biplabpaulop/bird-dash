BIRD DASH - Android project
1. Install Android Studio (developer.android.com/studio) on a computer.
2. File > Open > choose this BirdDash folder. Wait for Gradle sync to finish.
   (If asked to upgrade the Android Gradle Plugin, accept.)
3. Build > Build Bundle(s) / APK(s) > Build APK(s). Click "locate" when done.
4. Copy app-debug.apk to your phone and open it (allow "install unknown apps").
For Play Store: Build > Generate Signed App Bundle / APK > Android App Bundle.
The game page is app/src/main/assets/index.html
